package persistentie;

class Connectie {

    public static final String JDBC_URL = "jdbc:mysql://ID222177_g15.db.webhosting.be?user=ID222177_g15&password=QuedLif6";
}
